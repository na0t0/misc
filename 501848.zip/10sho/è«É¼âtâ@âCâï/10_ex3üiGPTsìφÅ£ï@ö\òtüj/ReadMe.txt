このブックファイルには作成したGPTsを削除できるシートが追加されています。
［GPTs削除］シートにある「FileID」に、削除したいFileIDを入力し、［ファイル削除］をクリックすれば削除完了です。
同様に「AssistantID」に、削除したいAssistantIDを入力すれば、削除することができます。
FileIDおよびAssistantIDは、作成されたMy GPTsシートのセルB2およびB3に表示されています。